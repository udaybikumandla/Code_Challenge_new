<?php

class AccountTest extends \PHPUnit\Framework\TestCase
{
    /**
     * A basic AccountTest.
     *
     * @return void
     */
    public function ApiCall($data)
    {
        $client = new GuzzleHttp\Client();
        $response = $client->get('http://localhost/bank-app-core/', [
            'json' => $data,
        ]);
        $this->assertEquals(200, $response->getStatusCode());
        return $data = json_decode($response->getBody(), true);
    }
    public function test_showBankList()
    {
        $inputData = ['api_type' => 'banklist'];
        $this->ApiCall($inputData);
    }

    public function test_create_account()
    {
        $inputData = [
            'api_type' => 'createaccount',
            'bankId' => '1',
            'accountTypeId' => '2',
            'accountSubTypeId' => '1',
            'ownerName' => 'uday',
            'mobile' => '9000749146',
            'address' => 'chepur near busstop 508256',
        ];
        $this->ApiCall($inputData);
    }

    public function test_show_account_list()
    {
        $inputData = [
            'api_type' => 'accountowner',
            'bank_id' => '1',
        ];
        $this->ApiCall($inputData);
    }

    public function test_single_account_data()
    {
        $inputData = [
            'api_type' => 'accountdetails',
            'ownerId' => '3',
            'accountNumber' => '5010050869',
        ];
        $this->ApiCall($inputData);
    }

    public function test_remove_account()
    {
        $inputData = [
            'api_type' => 'accountdetails',
            'ownerId' => '3',
            'accountNumber' => '5010050869',
        ];
        $this->ApiCall($inputData);
    }

    public function test_account_deposit()
    {
        $inputData = [
            'api_type' => 'banktransaction',
            'bank_id' => '1',
            'ownerId' => '3',
            'accountNumber' => '5010050869',
            'transactionType' => 'Deposit',
            'amount' => '500',
            'tarnsactionMode' => 'CASH',
        ];
        $this->ApiCall($inputData);
    }

    public function test_update_account()
    {
        $inputData = [
            'api_type' => 'updateaccount',
            'bankid' => '1',
            'ownerId' => '2',
            'accountTypeId' => '2',
            'accountSubTypeId' => '1',
            'ownerName' => 'uday kumar',
            'mobile' => '7013970373',
            'address' => 'hyd moulali',
        ];
        $this->ApiCall($inputData);
    }
    public function test_account_withdrawal()
    {
        $inputData = [
            'api_type' => 'bankwithdrawaltransaction',
            'bank_id' => '1',
            'ownerId' => '1',
            'account_no' => '5010068000',
            'transactionType' => 'withdrawal',
            'tarnsactionMode' => 'uday kumar',
            'mobile' => 'CASH',
            'amount' => '501',
        ];
        $this->ApiCall($inputData);
    }

    public function test_transferAmount()
    {
        $inputData = [
            'api_type' => 'balancetransfer',
            'bank_id' => '1',
            'ownerId' => '1',
            'account_no' => '5010068000',
            'transactionType' => 'Transfer',
            'tarnsactionMode' => 'NEFT',
            'mobile' => 'CASH',
            'amount' => '50',
            'tobankid' => '1',
            'toOwnerid' => '3',
            'toaccountno' => '5010050869',
        ];
        $this->ApiCall($inputData);
    }

    public function test_account_type_with_name()
    {
        $inputData = [
            'api_type' => 'accountdetailschekcing',
            'ownerId' => '1',
        ];
        $this->ApiCall($inputData);
    }
}

?>
