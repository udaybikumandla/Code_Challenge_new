<?php
session_start();
include 'cls/Bank.php';
include 'Headers.php';
use \Exception;

$bank = new \Banking\Bank();
try {
    if ($request['api_type'] == 'banklist') {
        $bankList = $bank->getBanks();
        $data = [
            'status' => 'success',
            'data' => $bankList,
            'message' => 'Bank List',
        ];
        echo json_encode($data);
    } else {
        throw new Exception('API type invalied');
    }
} catch (\Exception $e) {
    $data = [
        'status' => 'failed',
        'message' => $e->getMessage(),
    ];
    echo json_encode($data);
}
