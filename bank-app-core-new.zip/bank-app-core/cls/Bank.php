<?php
namespace Banking;

class Bank
{
    protected $allBank = [];
    protected $accountTypes = [];
    protected $subAccountTypes = [];

    public function __construct()
    {
    }

    public function getBanks()
    {
        $allBank = [
            [
                'id' => '1',
                'bank_name' => 'HDFC',
                'status' => 'Active',
            ],
            [
                'id' => '2',
                'bank_name' => 'ICICI',
                'status' => 'Active',
            ],
        ];
        return $allBank;
    }

    public function accountTypes()
    {
        $accountTypes = [
            [
                'id' => '1',
                'type' => 'Checking',
            ],
            [
                'id' => '2',
                'type' => 'investment',
            ],
        ];
        return $accountTypes;
    }

    public function subAccountTypes()
    {
        $subAccountTypes = [
            [
                'id' => '1',
                'account_type_id' => '2',
                'account_sub_type' => 'individual',
            ],
            [
                'id' => '2',
                'account_type_id' => '2',
                'account_sub_type' => 'corporate',
            ],
        ];
        return $subAccountTypes;
    }

    public function getBankDataUsingId($id)
    {
        $bank_data = [];
        foreach ($this->getBanks() as $key => $bank) {
            if (in_array($id, $bank)) {
                $bank_data['bank_name'] = $bank['bank_name'];
            }
        }
        return $bank_data;
    }
}

?>
