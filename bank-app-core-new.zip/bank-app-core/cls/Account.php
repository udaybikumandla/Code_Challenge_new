<?php

namespace Accounts;

require_once 'Bank.php';
include 'Headers.php';
use \Exception;
use Banking\Bank as Bank;

class Account extends Bank
{
    public $bankId;
    public $bankAccountTypeId;
    public $bankSubAccountTypeId;

    public function __construct()
    {
        parent::__construct();
    }

    public function getAccountTypeByUsingId($id)
    {
        $account_type = [];
        foreach ($this->accountTypes() as $key => $accountType) {
            if (in_array($id, $accountType)) {
                $account_type['type'] = $accountType['type'];
            }
        }
        return $account_type;
    }

    public function getSubAccountTypeByUsingId($id)
    {
        $subAccount_type = [];
        foreach ($this->subAccountTypes() as $key => $subAccountType) {
            if (in_array($id, $subAccountType)) {
                if ($subAccountType['id'] == $id) {
                    $subAccount_type['account_sub_type'] =
                        $subAccountType['account_sub_type'];
                }
            }
        }
        return $subAccount_type;
    }
    public static function validationRequired($inputField)
    {
        if (isset($inputField) && !empty($inputField)) {
            return true;
        } else {
            return false;
        }
    }
    public function insertValidation($data)
    {
        $return = [];
        if (Account::validationRequired($data['bankId']) == false) {
            $return['status'] = false;
            $return['message'] = 'Please provide bank id';
        } elseif (
            Account::validationRequired($data['accountTypeId']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide bank account type id';
        } elseif (
            Account::validationRequired($data['accountSubTypeId']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide bank sub account type id';
        } elseif (Account::validationRequired($data['ownerName']) == false) {
            $return['status'] = false;
            $return['message'] = 'Please provide owner name';
        } elseif (!preg_match('/^([a-zA-Z ]*)$/', $data['ownerName'])) {
            $return['status'] = false;
            $return['message'] =
                'Owner name should be only alphabets and whitespace allowed';
        } elseif (Account::validationRequired($data['mobile']) == false) {
            $return['status'] = false;
            $return['message'] = 'Please provide mobile number.';
        } elseif (Account::validationRequired($data['address']) == false) {
            $return['status'] = false;
            $return['message'] = 'Please provide address.';
        } else {
            $return['status'] = true;
        }
        return $return;
    }

    public function DepositValidation($data)
    {
        $return = [];
        if (Account::validationRequired($data['ownerId']) == false) {
            $return['status'] = false;
            $return['message'] = 'Please provide ownerId.';
        } elseif (Account::validationRequired($data['bank_id']) == false) {
            $return['status'] = false;
            $return['message'] = 'Please provide bank id.';
        } elseif (
            Account::validationRequired($data['transactionType']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide transactionType.';
        } elseif ($data['transactionType'] != 'Deposit') {
            $return['status'] = false;
            $return['message'] = 'TransactionType invalied.';
        } elseif (Account::validationRequired($data['amount']) == false) {
            $return['status'] = false;
            $return['message'] = 'Please provide amount.';
        } elseif (
            Account::validationRequired($data['tarnsactionMode']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide tarnsactionMode.';
        } else {
            $return['status'] = true;
        }
        return $return;
    }

    public function UpdateAccountValidation($data)
    {
        $return = [];
        if (Account::validationRequired($data['bankid']) == false) {
            $return['status'] = false;
            $return['message'] = 'Please provide bank id.';
        } elseif (
            Account::validationRequired($data['accountTypeId']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide account type id.';
        } elseif (
            Account::validationRequired($data['accountSubTypeId']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide sub account type id.';
        } elseif (Account::validationRequired($data['ownerId']) == false) {
            $return['status'] = false;
            $return['message'] = 'Please provide owner ID';
        } elseif (Account::validationRequired($data['ownerName']) == false) {
            $return['status'] = false;
            $return['message'] = 'Please provide owner name';
        } elseif (!preg_match('/^([a-zA-Z ]*)$/', $data['ownerName'])) {
            $return['status'] = false;
            $return['message'] =
                'Owner name should be only alphabets.';
        } elseif (Account::validationRequired($data['mobile']) == false) {
            $return['status'] = false;
            $return['message'] = 'Please provide mobile number.';
        } elseif (Account::validationRequired($data['address']) == false) {
            $return['status'] = false;
            $return['message'] = 'Please provide address.';
        } else {
            $return['status'] = true;
        }
        return $return;
    }

    public function WithdrawalValidations($data)
    {
        $return = [];
        if (Account::validationRequired($data['bank_id']) == false) {
            $return['status'] = false;
            $return['message'] = 'Please provide bank id.';
        } elseif (
            Account::validationRequired($data['ownerId']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide owner id.';
        }
        elseif (
            Account::validationRequired($data['account_no']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide account number.';
        }
        elseif (
            Account::validationRequired($data['transactionType']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide transactionType.';
        }
        elseif ( $data['transactionType']!='withdrawal' ) {
            $return['status'] = false;
            $return['message'] = 'Please provide transactionType invalied.';
        }
        elseif (
            Account::validationRequired($data['tarnsactionMode']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide tarnsactionMode.';
        }
        elseif (
            Account::validationRequired($data['amount']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide amount.';
        }
        else {
            $return['status'] = true;
        }
        return $return;
    }
    
    public function balancetransferValidation($data)
    {
        $return = [];
        if (Account::validationRequired($data['bank_id']) == false) {
            $return['status'] = false;
            $return['message'] = 'Please provide bank id.';
        } elseif (
            Account::validationRequired($data['ownerId']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide owner id.';
        }
        elseif (
            Account::validationRequired($data['account_no']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide account no.';
        }
        elseif (
            Account::validationRequired($data['transactionType']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide transactionType.';
        }
        elseif (
            Account::validationRequired($data['tarnsactionMode']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide tarnsactionMode.';
        }
        elseif (
            Account::validationRequired($data['amount']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide amount.';
        }
        elseif (
            Account::validationRequired($data['tobankid']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide tobankid.';
        }
        elseif (
            Account::validationRequired($data['toOwnerid']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide toOwnerid.';
        }
        elseif (
            Account::validationRequired($data['toaccountno']) == false
        ) {
            $return['status'] = false;
            $return['message'] = 'Please provide toaccountno.';
        }
        return $return;
    }
}

?>
