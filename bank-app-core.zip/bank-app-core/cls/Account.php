<?php

namespace Accounts;

require_once 'Bank.php';
include 'Headers.php';
use \Exception;
use Banking\Bank as Bank;

class Account extends Bank
{
    public $bankId;
    public $bankAccountTypeId;
    public $bankSubAccountTypeId;

    public function __construct()
    {
        parent::__construct();
    }

    public function getAccountTypeByUsingId($id)
    {
        $account_type = [];
        foreach ($this->accountTypes() as $key => $accountType) {
            if (in_array($id, $accountType)) {
                $account_type['type'] = $accountType['type'];
            }
        }
        return $account_type;
    }

    public function getSubAccountTypeByUsingId($id)
    {
        $subAccount_type = [];
        foreach ($this->subAccountTypes() as $key => $subAccountType) {
            if (
                in_array(
                    $id,
                    $subAccountType
                )
            ) {
                if ($subAccountType['id'] == $id) {
                    $subAccount_type['account_sub_type'] =
                        $subAccountType['account_sub_type'];
                }
            }
        }
        return $subAccount_type;
    }

   
}

?>
