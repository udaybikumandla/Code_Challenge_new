<?php

class AccountTest extends \PHPUnit\Framework\TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
    public function test_showBankList()
    {
        $client = new GuzzleHttp\Client();
        $response = $client->get('http://localhost/bank-app-core/', [
            'json' => [
                'api_type' => 'banklist',
            ],
        ]);
        $this->assertEquals(200, $response->getStatusCode());

        $data = json_decode($response->getBody(), true);
    }
    public function test_create_account()
    {
        $client = new GuzzleHttp\Client();
        $response = $client->post(
            'http://localhost/bank-app-core/account.php',
            [
                'api_type' => 'createaccount',
                'bankId' => '1',
                'accountTypeId' => '2',
                'accountSubTypeId' => '1',
                'ownerName' => 'uday',
                'mobile' => '9000749146',
                'address' => 'chepur near busstop 508256',
            ]
        );
        $data = json_decode($response->getBody(), true);
        $this->assertEquals(200, $response->getStatusCode());
    }

    public function test_show_account_list()
    {
        $client = new GuzzleHttp\Client();
        $response = $client->get('http://localhost/bank-app-core/account.php', [
            'json' => [
                'api_type' => 'accountowner',
                'bank_id' => '1',
            ],
        ]);
        $this->assertEquals(200, $response->getStatusCode());
    }

    public function test_single_account_data()
    {
        $client = new GuzzleHttp\Client();
        $response = $client->get('http://localhost/bank-app-core/account.php', [
            'json' => [
                'api_type' => 'accountdetails',
                'ownerId' => '3',
                'accountNumber' => '5010050869',
            ],
        ]);
        $this->assertEquals(200, $response->getStatusCode());
    }

    public function test_remove_account()
    {
        $client = new GuzzleHttp\Client();
        $response = $client->post(
            'http://localhost/bank-app-core/account.php',
            [
                'json' => [
                    'api_type' => 'accountdetails',
                    'ownerId' => '3',
                    'accountNumber' => '5010050869',
                ],
            ]
        );
        $this->assertEquals(200, $response->getStatusCode());
    }

    public function test_account_deposit()
    {
        $client = new GuzzleHttp\Client();
        $response = $client->post(
            'http://localhost/bank-app-core/account.php',
            [
                'json' => [
                    'api_type' => 'banktransaction',
                    'bank_id' => '1',
                    'ownerId' => '3',
                    'accountNumber' => '5010050869',
                    'transactionType' => 'Deposit',
                    'amount' => '500',
                    'tarnsactionMode' => 'CASH',
                ],
            ]
        );
        $this->assertEquals(200, $response->getStatusCode());
    }

    public function test_update_account()
    {
        $client = new GuzzleHttp\Client();
        $response = $client->post(
            'http://localhost/bank-app-core/account.php',
            [
                'json' => [
                    'api_type' => 'updateaccount',
                    'bankid' => '1',
                    'ownerId' => '2',
                    'accountTypeId' => '2',
                    'accountSubTypeId' => '1',
                    'ownerName' => 'uday kumar',
                    'mobile' => '7013970373',
                    'address' => 'hyd moulali',
                ],
            ]
        );
        $this->assertEquals(200, $response->getStatusCode());
    }
    public function test_account_withdrawal()
    {
        $client = new GuzzleHttp\Client();
        $response = $client->post(
            'http://localhost/bank-app-core/account.php',
            [
                'json' => [
                    'api_type' => 'bankwithdrawaltransaction',
                    'bank_id' => '1',
                    'ownerId' => '1',
                    'account_no' => '5010068000',
                    'transactionType' => 'withdrawal',
                    'tarnsactionMode' => 'uday kumar',
                    'mobile' => 'CASH',
                    'amount' => '501',
                ],
            ]
        );
        $this->assertEquals(200, $response->getStatusCode());
    }

    public function test_transferAmount()
    {
        $client = new GuzzleHttp\Client();
        $response = $client->post(
            'http://localhost/bank-app-core/account.php',
            [
                'json' => [
                    'api_type' => 'balancetransfer',
                    'bank_id' => '1',
                    'ownerId' => '1',
                    'account_no' => '5010068000',
                    'transactionType' => 'Transfer',
                    'tarnsactionMode' => 'NEFT',
                    'mobile' => 'CASH',
                    'amount' => '50',
                    'tobankid' => '1',
                    'toOwnerid' => '3',
                    'toaccountno' => '5010050869',
                ],
            ]
        );
        $this->assertEquals(200, $response->getStatusCode());
    }

    public function test_account_type_with_name()
    {
        $client = new GuzzleHttp\Client();
        $response = $client->post(
            'http://localhost/bank-app-core/account.php',
            [
                'json' => [
                    'api_type' => 'accountdetailschekcing',
                    'ownerId' => '1',
                ],
            ]
        );
        $this->assertEquals(200, $response->getStatusCode());
    }
}

?>
